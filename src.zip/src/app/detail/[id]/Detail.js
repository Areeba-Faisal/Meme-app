"use client"

import { useState } from "react";
import "./detail.css";

export default function Detail(response) {
  const [text, setText] = useState("");
  const [text1, setText1] = useState("");
  const [gen, setGen] = useState(null);

  if (!response || !response.response || response.response.length === 0) {
    return <div>No meme found.</div>;
  }

  const generateMeme = async () => {
    if (!text || !text1) {
      console.error("Text fields are required");
      return;
    }

    const username = "Arfa-Shoukat"; 
    const password = "Arfa$123"; 

    const url = `https://api.imgflip.com/caption_image?template_id=${response.response[0].id}&username=${username}&password=${password}&text0=${text}&text1=${text1}`;

    try {
      const response = await fetch(url, {
        method: "POST",
      });

      if (!response.ok) {
        throw new Error("Failed to generate meme");
      }

      const data = await response.json();
      setGen(data);
    } catch (error) {
      console.error("Error generating meme:", error);
    }
  };

  return (
    <div className="container">
      {!gen ? (
        <>
          <img className="meme-image" src={response.response[0].url} alt="Meme" />
          <div className="input-container">
            <input
              className="text-input"
              placeholder="Enter text 1"
              value={text}
              onChange={(e) => setText(e.target.value)}
            />
            <input
              className="text-input"
              placeholder="Enter text 2"
              value={text1}
              onChange={(e) => setText1(e.target.value)}
            />
          </div>
          <button className="generate-button" onClick={generateMeme}>
            Generate Meme
          </button>
        </>
      ) : (
        <img className="generated-meme" src={gen.data.url} alt="Generated Meme" />
      )}
    </div>
  );
}
